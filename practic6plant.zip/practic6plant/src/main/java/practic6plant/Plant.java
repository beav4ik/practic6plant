package practic6plant;
import java.io.*;

public class Plant implements Externalizable {
    private String name;
    private String species;
    private int age;
    transient private int height;
    private boolean isThorny;

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(name);
        out.writeObject(species);
        out.writeInt(age);
        out.writeBoolean(isThorny);
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        name = (String) in.readObject();
        species = (String) in.readObject();
        age = in.readInt();
        isThorny = in.readBoolean();
    }

    public void saveToFile() {
        String fileName = "C:\\plant.ser";
        try (OutputStream fileOutputStream = new FileOutputStream(fileName);
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
            objectOutputStream.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Ваше растение было сохранено в: " + fileName);
    }

    public void fillFields() throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Бобровский С.И., РИБО-01-21, Вариант №4, Практика №6");
        System.out.print("Введите название растения: ");
        name = reader.readLine();
        System.out.print("Введите особенности растения: ");
        species = reader.readLine();
        System.out.print("Введите возраст растения: ");
        age = Integer.parseInt(reader.readLine());
        System.out.print("Введите высоту растения: ");
        height = Integer.parseInt(reader.readLine());
        System.out.print("Ваше растение в Красной Книге? (1 - да, 0 - нет): ");
        isThorny = Boolean.parseBoolean(reader.readLine());
    }

    public static void main(String[] args) throws IOException {
        Plant plant = new Plant();
        plant.fillFields();
        new Thread(() -> plant.saveToFile()).start();
    }
}